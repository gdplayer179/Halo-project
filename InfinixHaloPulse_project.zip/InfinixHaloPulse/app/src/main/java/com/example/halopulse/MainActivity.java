package com.example.halopulse;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.graphics.ImageFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String HALO_CHANNEL = "halo_pulse_start_v1";
    private static final int HALO_NOTIFICATION_ID = 713;
    private static final int PERMISSION_REQUEST = 32;
    private static final long RUN_MS = 20000;
    private final PPGAnalyzer analyzer = new PPGAnalyzer();
    private final Handler uiHandler = new Handler(android.os.Looper.getMainLooper());
    private CameraManager cameraManager;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraSession;
    private ImageReader reader;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private volatile boolean active = false;
    private volatile boolean fingerDetected = false;
    private volatile long lastFrameUi = 0;
    private long startedAt = 0;
    private TextView resultText, statusText, guideText, timerText, haloText;
    private Button measureButton;
    private View heartDot;
    private ObjectAnimator heartAnim;
    private PPGGraph graph;
    private NotificationManager notifications;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraManager = (CameraManager)getSystemService(Context.CAMERA_SERVICE);
        notifications = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
        createUi();
    }

    private int dp(float v) { return (int)(getResources().getDisplayMetrics().density*v + 0.5f); }
    private GradientDrawable shape(int color, float radius) {
        GradientDrawable b = new GradientDrawable();
        b.setColor(color);
        b.setCornerRadius(dp(radius));
        return b;
    }
    private TextView label(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return t;
    }
    private void createUi() {
        int navy = Color.rgb(8, 13, 32), cardColor = Color.rgb(21, 31, 58);
        int soft = Color.rgb(169, 190, 221), cyan = Color.rgb(93, 228, 239);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setBackgroundColor(navy);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL); main.setPadding(dp(22),dp(30),dp(22),dp(28));
        main.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        main.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(main);
        setContentView(scroll);

        TextView heading = label("نبضي  •  Halo Pulse", 27, Color.WHITE);
        heading.setTypeface(null, 1);
        main.addView(heading);
        TextView subtitle = label("قياس بصري تقريبي للنبض باستخدام كاميرا الهاتف", 14, soft);
        topSpace(main, 8); main.addView(subtitle);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER);
        card.setPadding(dp(18),dp(24),dp(18),dp(20));
        card.setBackground(shape(cardColor,24));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1,-2);
        cardParams.topMargin = dp(26);
        main.addView(card,cardParams);

        heartDot = new View(this);
        GradientDrawable heartBackground = shape(Color.rgb(237,72,129),100);
        heartBackground.setStroke(dp(4),Color.rgb(255,125,171));
        heartDot.setBackground(heartBackground);
        heartDot.setContentDescription("مؤشر بصري متحرك أثناء القياس");
        card.addView(heartDot,new LinearLayout.LayoutParams(dp(62),dp(62)));

        resultText=label("—",66,cyan);
        resultText.setTypeface(null,1);
        topSpace(card,13);card.addView(resultText);
        card.addView(label("نبضة بالدقيقة · BPM",16,soft));
        timerText=label("مدة القياس: 20 ثانية",13,soft);
        topSpace(card,14);card.addView(timerText);
        statusText=label("جاهز للقياس",16,Color.WHITE);
        topSpace(card,12);card.addView(statusText);
        guideText=label("ضع طرف إصبعك بلطف فوق الكاميرا الخلفية والفلاش عند بدء القياس.",14,soft);
        topSpace(card,8);card.addView(guideText);

        TextView graphTitle = label("الموجة الضوئية PPG (ليست ECG)",15,cyan);
        topSpace(main,24);main.addView(graphTitle);
        graph = new PPGGraph(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1,dp(140));
        gp.topMargin=dp(10);
        main.addView(graph,gp);

        measureButton = new Button(this);
        measureButton.setText("بدء قياس النبض");
        measureButton.setAllCaps(false);
        measureButton.setTextColor(navy);measureButton.setTextSize(18);
        measureButton.setBackground(shape(cyan,17));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,dp(60));
        bp.topMargin=dp(19);main.addView(measureButton,bp);
        measureButton.setOnClickListener(v -> { if(active) stopMeasurement(false); else requestThenStart(); });

        haloText=label("الهالة الخلفية: نحاول تنشيطها بإشعار عند بدء القياس. يتطلب ذلك تفعيل Active Halo لإشعارات هذا التطبيق في XOS.",14,soft);
        topSpace(main,17);main.addView(haloText);
        TextView disclosure=label("هذا تقدير غير طبي للنبض. لا يستطيع الهاتف استخراج تخطيط قلب ECG حقيقي دون جهاز مختص. لا تعتمد على القراءة لاتخاذ قرارات طبية.",13,Color.rgb(232,188,194));
        topSpace(main,19);main.addView(disclosure);
    }
    private void topSpace(LinearLayout target,int size) {
        View space = new View(this);
        target.addView(space,new LinearLayout.LayoutParams(1,dp(size)));
    }
    private void requestThenStart() {
        List<String> needed = new ArrayList<>();
        if(checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.CAMERA);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]),PERMISSION_REQUEST);
        else startMeasurement();
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] grants) {
        super.onRequestPermissionsResult(code,permissions,grants);
        if(code==PERMISSION_REQUEST) {
            if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)
                startMeasurement();
            else statusText.setText("يجب السماح بالوصول إلى الكاميرا لقياس النبض.");
        }
    }
    private void startMeasurement() {
        if(active) return;
        active=true;
        fingerDetected=false;
        startedAt=SystemClock.elapsedRealtime();
        lastFrameUi=0;
        analyzer.reset();
        resultText.setText("—");
        statusText.setText("يجري تشغيل الكاميرا...");
        guideText.setText("غطِّ العدسة والفلاش بلطف دون الضغط بشدة.");
        timerText.setText("0 / 20 ثانية");
        measureButton.setText("إيقاف القياس");
        graph.reset();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        heartAnim = ObjectAnimator.ofPropertyValuesHolder(heartDot,
                PropertyValuesHolder.ofFloat(View.SCALE_X,1f,1.20f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y,1f,1.20f));
        heartAnim.setDuration(550);
        heartAnim.setRepeatCount(ValueAnimator.INFINITE);
        heartAnim.setRepeatMode(ValueAnimator.REVERSE);
        heartAnim.start();
        cameraThread=new HandlerThread("optical-ppg-camera");cameraThread.start();
        cameraHandler=new Handler(cameraThread.getLooper());
        openCamera();
        uiHandler.post(tick);
    }
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if(!active) return;
            long elapsed = SystemClock.elapsedRealtime()-startedAt;
            timerText.setText(Math.min(20,elapsed/1000) + " / 20 ثانية");
            if(elapsed >= RUN_MS) { stopMeasurement(true); return; }
            uiHandler.postDelayed(this,200);
        }
    };
    private void openCamera() {
        try {
            if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
                failure("إذن الكاميرا غير متاح"); return;
            }
            String id = null;
            for(String candidate: cameraManager.getCameraIdList()) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(candidate);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if(facing!=null && facing==CameraCharacteristics.LENS_FACING_BACK && Boolean.TRUE.equals(flash)) {
                    id=candidate;break;
                }
            }
            if(id==null) { failure("لم يتم العثور على كاميرا خلفية مزودة بفلاش");return; }
            CameraCharacteristics cc = cameraManager.getCameraCharacteristics(id);
            StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            android.util.Size chosen = new android.util.Size(640,480);
            if(map!=null && map.getOutputSizes(ImageFormat.YUV_420_888)!=null) {
                android.util.Size[] sizes=map.getOutputSizes(ImageFormat.YUV_420_888);
                android.util.Size best=null;
                for(android.util.Size s:sizes) {
                    long area=(long)s.getWidth()*s.getHeight();
                    if(area>=76800 && (best==null || area<(long)best.getWidth()*best.getHeight())) best=s;
                }
                if(best==null) for(android.util.Size s:sizes)
                    if(best==null || (long)s.getWidth()*s.getHeight()<(long)best.getWidth()*best.getHeight()) best=s;
                if(best!=null) chosen=best;
            }
            reader=ImageReader.newInstance(chosen.getWidth(),chosen.getHeight(),ImageFormat.YUV_420_888,3);
            reader.setOnImageAvailableListener(r -> readFrame(r),cameraHandler);
            cameraManager.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice camera) {
                    if(!active) {camera.close();return;}
                    cameraDevice=camera;
                    try {
                        camera.createCaptureSession(Arrays.asList(reader.getSurface()),new CameraCaptureSession.StateCallback() {
                            @Override public void onConfigured(CameraCaptureSession session) {
                                if(!active) {session.close();return;}
                                cameraSession=session;
                                try {
                                    CaptureRequest.Builder req=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                    req.addTarget(reader.getSurface());
                                    req.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);
                                    req.set(CaptureRequest.FLASH_MODE,CaptureRequest.FLASH_MODE_TORCH);
                                    session.setRepeatingRequest(req.build(),null,cameraHandler);
                                    uiHandler.post(() -> {
                                        if(!active) return;
                                        statusText.setText("يجري التقاط الإشارة الضوئية...");
                                        sendHaloNotification();
                                    });
                                } catch(Exception e) { failure("تعذر تشغيل فلاش الكاميرا"); }
                            }
                            @Override public void onConfigureFailed(CameraCaptureSession session) {failure("فشل إعداد الكاميرا");}
                        },cameraHandler);
                    } catch(Exception e) { failure("تعذر بدء تصوير القياس"); }
                }
                @Override public void onDisconnected(CameraDevice camera) {camera.close();failure("انقطع اتصال الكاميرا");}
                @Override public void onError(CameraDevice camera,int error) {camera.close();failure("خطأ في تشغيل الكاميرا: "+error);}
            },cameraHandler);
        } catch(Exception e) {failure("تعذر الوصول إلى الكاميرا: "+e.getClass().getSimpleName());}
    }
    private void readFrame(ImageReader r) {
        Image img=null;
        try {
            img=r.acquireLatestImage();
            if(img==null || !active) return;
            Image.Plane[] p=img.getPlanes();
            if(p.length<3) return;
            ByteBuffer Y=p[0].getBuffer(),U=p[1].getBuffer(),V=p[2].getBuffer();
            int w=img.getWidth(),h=img.getHeight();
            double rSum=0,gSum=0;int n=0;
            // Sample a central region while respecting Android YUV row/pixel strides.
            for(int y=h/4; y<3*h/4; y+=Math.max(2,h/60)) {
                for(int x=w/4; x<3*w/4; x+=Math.max(2,w/60)) {
                    int yp=y*p[0].getRowStride()+x*p[0].getPixelStride();
                    int up=(y/2)*p[1].getRowStride()+(x/2)*p[1].getPixelStride();
                    int vp=(y/2)*p[2].getRowStride()+(x/2)*p[2].getPixelStride();
                    if(yp>=Y.limit() || up>=U.limit() || vp>=V.limit()) continue;
                    int l=Y.get(yp)&255, cb=(U.get(up)&255)-128, cr=(V.get(vp)&255)-128;
                    double red=Math.max(0,Math.min(255,l+1.402*cr));
                    double green=Math.max(0,Math.min(255,l-0.344136*cb-0.714136*cr));
                    rSum+=red;gSum+=green;n++;
                }
            }
            if(n==0) return;
            final double red=rSum/n,green=gSum/n;
            boolean covered=red>70 && red>green*1.11;
            if(!covered) {
                if(fingerDetected) analyzer.reset();
                fingerDetected=false;
            } else {
                fingerDetected=true;
                // Saturated red cannot carry a useful pulse signal; fall back to green.
                analyzer.add(SystemClock.elapsedRealtime()/1000.0, red>=248?green:red);
            }
            long now=SystemClock.elapsedRealtime();
            if(now-lastFrameUi>180) {
                lastFrameUi=now;
                List<PPGAnalyzer.Point> recent=analyzer.recent(130);
                uiHandler.post(() -> {
                    if(!active) return;
                    graph.setPoints(recent);
                    statusText.setText(fingerDetected ? "جاري تحليل التغيرات الضوئية..." : "غطِّ العدسة والفلاش للحصول على إشارة");
                });
            }
        } catch(Exception ignore) {
            // Dropped frames are normal on some camera HAL implementations.
        } finally {if(img!=null)img.close();}
    }
    private void stopMeasurement(boolean completed) {
        if(!active)return;
        int bpm = completed ? analyzer.estimateBpm() : -1;
        active=false;
        uiHandler.removeCallbacks(tick);
        if(heartAnim!=null){heartAnim.cancel();heartAnim=null;}
        heartDot.setScaleX(1f);heartDot.setScaleY(1f);
        measureButton.setText("بدء قياس النبض");
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(completed && fingerDetected && bpm>0) {
            resultText.setText(String.valueOf(bpm));
            statusText.setText("النتيجة تقديرية وليست تشخيصاً");
            guideText.setText("إذا بدت القراءة غير منطقية، أعد المحاولة بهدوء.");
        } else if(completed) {
            resultText.setText("—");
            statusText.setText("تعذر استخراج قراءة موثوقة");
            guideText.setText("حاول تثبيت إصبعك بلطف على العدسة والفلاش طوال القياس.");
        } else {
            statusText.setText("أوقفت القياس");
        }
        if(cameraSession!=null){try{cameraSession.close();}catch(Exception ignored){}cameraSession=null;}
        if(cameraDevice!=null){try{cameraDevice.close();}catch(Exception ignored){}cameraDevice=null;}
        if(reader!=null){try{reader.close();}catch(Exception ignored){}reader=null;}
        if(cameraThread!=null){cameraThread.quitSafely();cameraThread=null;cameraHandler=null;}
        notifications.cancel(HALO_NOTIFICATION_ID);
    }
    private void failure(String error) {
        uiHandler.post(() -> {if(active){stopMeasurement(false);statusText.setText(error);}});
    }
    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(HALO_CHANNEL,"إشعار بدء قياس النبض",NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("إشعار بدء القياس، ويمكن لإعدادات XOS استخدامه مع إضاءة Active Halo.");
        channel.enableLights(true);
        channel.setLightColor(Color.CYAN);
        channel.enableVibration(false);
        notifications.createNotificationChannel(channel);
    }
    private void sendHaloNotification() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            haloText.setText("فعّل إذن الإشعارات ثم خيار Active Halo لإشعارات هذا التطبيق من إعدادات الهاتف.");
            return;
        }
        Notification n = new Notification.Builder(this,HALO_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_info)
                .setContentTitle("بدأ قياس النبض 🫀")
                .setContentText("القياس بالكاميرا والفلاش قيد التشغيل")
                .setShowWhen(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .build();
        notifications.notify(HALO_NOTIFICATION_ID,n);
        haloText.setText("أُرسل إشعار بدء القياس. إضاءة Active Halo الفعلية تتوقف على دعم وإعدادات XOS.");
    }
    @Override protected void onPause() {
        super.onPause();
        // The camera must not keep recording if the user leaves the measurement screen.
        if(active)stopMeasurement(false);
    }
    @Override protected void onDestroy() {
        if(active)stopMeasurement(false);
        super.onDestroy();
    }

    static final class PPGGraph extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<PPGAnalyzer.Point> data = new ArrayList<>();
        PPGGraph(Context context) {super(context);}
        void reset(){data=new ArrayList<>();invalidate();}
        void setPoints(List<PPGAnalyzer.Point> points){data=points;invalidate();}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(),h=getHeight();
            p.setColor(Color.rgb(19,31,55));p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(0,0,w,h,18,18,p);
            p.setColor(Color.rgb(42,65,88));p.setStrokeWidth(1);
            for(int k=1;k<4;k++)c.drawLine(0,h*k/4f,w,h*k/4f,p);
            if(data.size()<2)return;
            double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
            for(PPGAnalyzer.Point pt:data){min=Math.min(min,pt.brightness);max=Math.max(max,pt.brightness);}
            if(max-min<0.3) max=min+0.3;
            p.setColor(Color.rgb(93,228,239));p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);
            for(int i=1;i<data.size();i++){
                float x1=(i-1)*(w-20f)/(data.size()-1)+10;
                float x2=i*(w-20f)/(data.size()-1)+10;
                float y1=(float)(h-12-(data.get(i-1).brightness-min)/(max-min)*(h-24));
                float y2=(float)(h-12-(data.get(i).brightness-min)/(max-min)*(h-24));
                c.drawLine(x1,y1,x2,y2,p);
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
