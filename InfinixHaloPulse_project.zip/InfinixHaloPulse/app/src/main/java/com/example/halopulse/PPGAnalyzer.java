package com.example.halopulse;

import java.util.ArrayList;
import java.util.List;

/**
 * Educational camera-based photoplethysmography (PPG) signal estimator.
 * This is not ECG and is not a medically validated pulse monitor.
 */
public final class PPGAnalyzer {
    public static final class Point {
        public final double timeSec;
        public final double brightness;
        Point(double t, double b) { timeSec = t; brightness = b; }
    }
    private final List<Point> points = new ArrayList<>();
    private double startSec = -1;

    public synchronized void reset() {
        points.clear();
        startSec = -1;
    }

    public synchronized void add(double timeSec, double brightness) {
        if (startSec < 0) startSec = timeSec;
        double elapsed = timeSec - startSec;
        // Skip initial auto-exposure settling.
        if (elapsed >= 2.0 && elapsed <= 24.0) points.add(new Point(elapsed, brightness));
    }

    public synchronized int count() { return points.size(); }

    public synchronized List<Point> recent(int max) {
        int from = Math.max(0, points.size() - max);
        return new ArrayList<>(points.subList(from, points.size()));
    }

    /** Best-fit harmonic frequency of detrended optical pulse wave. */
    public synchronized int estimateBpm() {
        if (points.size() < 120) return -1;
        double duration = points.get(points.size()-1).timeSec - points.get(0).timeSec;
        if (duration < 10) return -1;
        int n = points.size();
        double[] v = new double[n];
        double mean = 0;
        for (Point p : points) mean += p.brightness;
        mean /= n;
        double variance = 0;
        for (Point p : points) variance += Math.pow(p.brightness - mean, 2);
        double std = Math.sqrt(variance / n);
        if (std < 0.15) return -1;
        // Remove slow movement / exposure drift using 1.2 second local averages.
        for (int i=0; i<n; i++) {
            double center = points.get(i).timeSec;
            double sum = 0; int count = 0;
            for (int j=0; j<n; j++) {
                if (Math.abs(points.get(j).timeSec - center) <= 0.6) {
                    sum += points.get(j).brightness; count++;
                }
            }
            v[i] = points.get(i).brightness - sum / Math.max(1, count);
        }
        double bestScore = -1;
        int bestBpm = -1;
        double scoreSum = 0;
        int candidates = 0;
        for (int bpm=48; bpm<=160; bpm++) {
            double re=0, im=0;
            for (int i=0; i<n; i++) {
                double sec = points.get(i).timeSec - points.get(0).timeSec;
                double weight = 0.5 - 0.5*Math.cos(2*Math.PI*i/Math.max(1,n-1));
                double angle = 2*Math.PI*(bpm/60.0)*sec;
                re += weight*v[i]*Math.cos(angle);
                im += weight*v[i]*Math.sin(angle);
            }
            double score = re*re+im*im;
            scoreSum += score;
            candidates++;
            if (score > bestScore) { bestScore=score; bestBpm=bpm; }
        }
        // Reject data that has no convincingly dominant periodic signal.
        if (bestScore < 3.5*(scoreSum/Math.max(1,candidates))) return -1;
        return bestBpm;
    }
}
